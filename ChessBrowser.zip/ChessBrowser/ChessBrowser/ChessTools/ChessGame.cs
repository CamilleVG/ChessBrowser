﻿using System;

namespace ChessTools
{
    public class ChessGame
    {
        //primary key of game
        //string Round;
        //int BlackPlayer;
        //int WhitePlayer;
        //int eID;

        //info in PGN file
        public string Event;
        public string Site;
        public string Date;
        public string Round;
        public string WhiteName;
        public string BlackName;
        public int WhiteElo;
        public int BlackElo;
        public char Result;
        public string ECO; //delete
        public string EventDate;
        public string Moves; 

        public ChessGame()
        {
        }

    }
}

