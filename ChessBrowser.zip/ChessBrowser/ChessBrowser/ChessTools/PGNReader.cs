﻿using System;
using System.IO;
using System.Collections.Generic;

using MySql.Data.MySqlClient;

namespace ChessTools
{
    static public class PGNReader
    {


        /// <summary>
        /// This function handles the "Upload PGN" button.
        /// Given a filename, parses the PGN file, and uploads
        /// each chess game to the user's database.
        /// </summary>
        /// <param name="PGNfilename">The path to the PGN file</param>
        public static void UploadGamesToDatabase(string PGNfilename)
        {
            // This will build a connection string to your user's database on atr,
            // assuimg you've typed a user and password in the GUI
            string connection = "server=atr.eng.utah.edu;" +
                "database=u0953582;" +
                "uid=u0953582;" +
                "password=RadBrie@3";

            // TODO: Load and parse the PGN file
            //       We recommend creating separate libraries to represent chess data and load the file

            // Use this to tell the GUI's progress bar how many total work steps there are
            // For example, one iteration of your main upload loop could be one work step
            // SetNumWorkItems(...);


            using (MySqlConnection conn = new MySqlConnection(connection))
            {
                //try
                //{
                    List<ChessGame> games = PGNReader.ReadFile(PGNfilename);
                    // Open a connection
                    conn.Open();
                    MySqlCommand cmd = conn.CreateCommand();

                ChessGame game = games[0];
                cmd.Parameters.AddWithValue("@BlackName", game.BlackName);
                cmd.Parameters.AddWithValue("@BlackElo", game.BlackElo);

                cmd.Parameters.AddWithValue("@WhiteName", game.WhiteName);
                cmd.Parameters.AddWithValue("@WhiteElo", game.WhiteElo);

                cmd.Parameters.AddWithValue("@EventName", game.Event);
                cmd.Parameters.AddWithValue("@EventDate", game.EventDate);
                cmd.Parameters.AddWithValue("@EventSite", game.Site);
                cmd.Parameters.AddWithValue("@Round", game.Round);
                cmd.Parameters.AddWithValue("@Result", game.Result);
                cmd.Parameters.AddWithValue("@Moves", game.Moves);

                cmd.CommandText = "insert ignore into Players(Name, Elo) values(@BlackName, @BlackElo) ON DUPLICATE KEY UPDATE Elo = IF( @BlackElo > Elo, @BlackElo, Elo);" +
                "insert ignore into Players(Name, Elo) values( @WhiteName, @WhiteElo) ON DUPLICATE KEY UPDATE Elo = IF( @WhiteElo > Elo, @WhiteElo, Elo);" +
                "insert ignore into Players(Name, Elo) values(@WhiteName, @WhiteElo) ON DUPLICATE KEY UPDATE Elo = IF( @WhiteElo > Elo, @WhiteElo, Elo);" +
                "insert ignore into Events(Name, Date, Site) values (@EventName, @EventDate, @EventSite);" +
                "insert ignore into Games(Round, Result, Moves, BlackPlayer, WhitePlayer, eID) values(@Round, @Result , @Moves, (select pID from Players where Name = @BlackName), (select pID from Players where Name = @WhiteName), (select eID from Events where Name = @EventName AND Date = @EventDate AND Site = @EventSite));";
         

                foreach (ChessGame g in games)
                    {

                    cmd.Parameters["@BlackName"].Value = g.BlackName;
                    cmd.Parameters["@BlackElo"].Value = g.BlackElo;
                    cmd.Parameters["@WhiteName"].Value = g.WhiteName;
                    cmd.Parameters["@WhiteElo"].Value = g.WhiteElo;
                    cmd.Parameters["@EventName"].Value = g.Event;
                    cmd.Parameters["@EventDate"].Value = g.EventDate;
                    cmd.Parameters["@EventSite"].Value = g.Site;
                    cmd.Parameters["@Round"].Value = g.Round;
                    cmd.Parameters["@Result"].Value = g.Result;
                    cmd.Parameters["@Moves"].Value = g.Moves;

                    int numRows = cmd.ExecuteNonQuery();
                    }
                    // TODO: iterate through your data and generate appropriate insert commands

                    // Use this to tell the GUI that one work step has completed:
                    // WorkStepCompleted();

                //}
                //catch (Exception e)
                //{
                 //   Console.WriteLine(e.Message);
                //}
            }
        }

        /// <summary>
        /// Queries the database for games that match all the given filters.
        /// The filters are taken from the various controls in the GUI.
        /// </summary>
        /// <param name="white">The white player, or "" if none</param>
        /// <param name="black">The black player, or "" if none</param>
        /// <param name="opening">The first move, e.g. "1.e4", or "" if none</param>
        /// <param name="winner">The winner as "White", "Black", "Draw", or "" if none</param>
        /// <param name="useDate">True if the filter includes a date range, False otherwise</param>
        /// <param name="start">The start of the date range</param>
        /// <param name="end">The end of the date range</param>
        /// <param name="showMoves">True if the returned data should include the PGN moves</param>
        /// <returns>A string separated by windows line endings ("\r\n") containing the filtered games</returns>
        public static string PerformQuery(string white, string black, string opening,
      string winner, bool useDate, DateTime start, DateTime end, bool showMoves)
        {
            // This will build a connection string to your user's database on atr,
            // assuimg you've typed a user and password in the GUI
            string connection = "server=atr.eng.utah.edu;" +
                "database=u0953582;" +
                "uid=u0953582;" +
                "password=RadBrie@3";

            // Build up this string containing the results from your query
            string parsedResult = "";

            // Use this to count the number of rows returned by your query
            // (see below return statement)
            int numRows = 0;

            using (MySqlConnection conn = new MySqlConnection(connection))
            {

                // Open a connection
                conn.Open();
                MySqlCommand cmd = conn.CreateCommand();

                cmd.Parameters.AddWithValue("@BlackName", black);
                cmd.Parameters.AddWithValue("@WhiteName", white);
                cmd.Parameters.AddWithValue("@Opening", opening + "%");
                cmd.Parameters.AddWithValue("@StartDate", start);
                cmd.Parameters.AddWithValue("@EndDate", end);

                switch(winner)
                {
                    case "Draw":
                        cmd.Parameters.AddWithValue("@Winner", 'D');
                        break;
                    case "White":
                        cmd.Parameters.AddWithValue("@Winner", 'W');
                        break;
                    case "Black":
                        cmd.Parameters.AddWithValue("@Winner", 'B');
                        break;
                }

                string Filter = "";

                string GetWHEREorAND() => String.IsNullOrEmpty(Filter) ? "WHERE" : " AND";

                if (!String.IsNullOrEmpty(white) && String.IsNullOrEmpty(Filter))
                {
                    Filter += GetWHEREorAND() + " WhitePlayer = (select pID from Players where Name = @WhiteName)";
                }
                if (!String.IsNullOrEmpty(black))
                {
                    Filter += GetWHEREorAND() + " BlackPlayer = (select pID from Players where Name = @BlackName)";
                }
                if (!String.IsNullOrEmpty(opening))
                {
                    Filter += GetWHEREorAND() + " Moves LIKE @Opening";
                }
                if (!String.IsNullOrEmpty(winner))
                {
                    Filter += GetWHEREorAND() + " Result = @Winner";
                }
                if (useDate)
                {
                    Filter += GetWHEREorAND() + " eID IN (select eID FROM Events WHERE Date BETWEEN @StartDate AND @EndDate)";
                }

                cmd.CommandText = "select * from (select Name as EventName, Site as EventSite, Date as EventDate from ((SELECT * FROM Games " + Filter + ") as Filter join Events on Filter.eID = Events.eID)) as event " +
                "join(select Name as White, Elo as WhiteElo from ((SELECT * FROM Games " + Filter + ") as Filter join Players on Filter.WhitePlayer = Players.pID)) as white " +
                "join(select Name as Black, Elo as BlackElo from ((SELECT * FROM Games " + Filter + ") as Filter join Players on Filter.BlackPlayer = Players.pID)) as black " +
                "join (SELECT Result, Moves FROM Games " + Filter + ") as result;";

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        parsedResult += "Event: " + reader["EventName"] + "\r\nSite: " + reader["EventSite"] + "\r\nDate: " + reader["EventDate"] + "\r\nWhite: " + reader["White"] + " (" + reader["WhiteElo"] + ")" + "\r\nBlack: " + reader["Black"] + " (" + reader["BlackElo"] + ")" + "\r\nResult: " + reader["Result"] + "\r\n\n";
                        if (showMoves)
                        {
                            parsedResult += "Moves: " + reader["Moves"] + "\r\n\n";
                        }
                        numRows++;
                    }
                }

            }
            return numRows + " results\r\n\r\n" + parsedResult;
        }



        public static List<ChessGame> ReadFile(string PGNfilename)
        {
            List<ChessGame> games = new List<ChessGame>();

            if (!File.Exists(PGNfilename))
            {
                return games;
            }

            ChessGame game = new ChessGame();

            string[] readText = File.ReadAllLines(PGNfilename);
            System.Collections.IEnumerator FileEnumerator = readText.GetEnumerator();
            while (FileEnumerator.MoveNext())
            {
                string currentLine = (string)FileEnumerator.Current;
                if (!String.IsNullOrWhiteSpace(currentLine)) //current game line is not blank
                {
                    if (currentLine.StartsWith("[Event "))
                    {
                        game.Event = currentLine.Substring(8, currentLine.Length - 8 - 2);
                        continue;
                    }
                    if (currentLine.StartsWith("[Site"))
                    {
                        game.Site = currentLine.Substring(7, currentLine.Length - 7 - 2);
                        continue;
                    }
                    if (currentLine.StartsWith("[Date"))
                    {
                        game.Date = currentLine.Substring(7, currentLine.Length - 7 - 2);
                        continue;
                    }
                    if (currentLine.StartsWith("[Round"))
                    {
                        game.Round = currentLine.Substring(8, currentLine.Length - 8 - 2);
                        continue;
                    }
                    if (currentLine.StartsWith("[White "))
                    {
                        game.WhiteName = currentLine.Substring(8, currentLine.Length - 8 - 2);
                        continue;
                    }
                    if (currentLine.StartsWith("[Black "))
                    {
                        game.BlackName = currentLine.Substring(8, currentLine.Length - 8 - 2);
                        continue;
                    }
                    if (currentLine.StartsWith("[Result"))
                    {
                        //A PGN Result of "1-0" means white won, "0-1" means black won, and "1/2-1/2" is a draw.
                        string score = currentLine.Substring(9, currentLine.Length - 9 - 2);
                        if (score.Equals("1-0"))
                            game.Result = 'W';
                        if (score.Equals("0-1"))
                            game.Result = 'B';
                        if (score.Equals("1/2-1/2"))
                            game.Result = 'D';
                        continue;
                    }
                    if (currentLine.StartsWith("[WhiteElo"))
                    {
                        game.WhiteElo = Int32.Parse(currentLine.Substring(11, currentLine.Length - 11 - 2));
                        continue;
                    }
                    if (currentLine.StartsWith("[BlackElo"))
                    {
                        game.BlackElo = Int32.Parse(currentLine.Substring(11, currentLine.Length - 11 - 2));
                        continue;
                    }
                    if (currentLine.StartsWith("[ECO"))
                    {
                        game.ECO = currentLine.Substring(6, currentLine.Length - 6 - 2);
                        continue;
                    }
                    if (currentLine.StartsWith("[EventDate"))
                    {
                        game.EventDate = currentLine.Substring(12, currentLine.Length - 12 - 2);
                        continue;
                    }
                }
                else
                {
                    if (!String.IsNullOrEmpty(game.Moves))
                    {
                        game = new ChessGame();
                        continue;
                    }
                    else
                    {
                        FileEnumerator.MoveNext();
                        currentLine = (string)FileEnumerator.Current;
                        string moves = currentLine;
                        while (!String.IsNullOrEmpty(currentLine) && FileEnumerator.MoveNext())
                        {
                            currentLine = (string)FileEnumerator.Current;
                            moves += currentLine;
                        }
                        game.Moves = moves;
                        games.Add(game);
                        game = new ChessGame();
                        continue;
                    }
                }

            }

            return games;
        }

    }

}
