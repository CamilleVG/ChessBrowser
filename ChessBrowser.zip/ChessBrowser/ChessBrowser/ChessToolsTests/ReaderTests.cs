﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ChessTools;
using System.Collections.Generic;
using System.IO;

using System;
using System.Reflection;

namespace ChessToolsTests
{
    [TestClass]
    public class ReaderTests
    {
        [TestMethod]
        public void Add1Game()
        {
            List<ChessGame> games = PGNReader.ReadFile("/Users/camillevanginkel/Projects/ChessBrowser/ChessBrowser/ChessToolsTests/Template.cshtml");
            Assert.AreEqual(games.Count, 1);
        }

        [TestMethod]
        public void TestCorrectNumOfGamesKB1()
        {
            List<ChessGame> games = PGNReader.ReadFile("/Users/camillevanginkel/Projects/ChessBrowser/ChessBrowser/ChessToolsTests/kb1.pgn");
            Assert.AreEqual(games.Count, 975);
        }
        [TestMethod]
        public void TestCorrectNumOfGamesKB2()
        {
            List<ChessGame> games = PGNReader.ReadFile("/Users/camillevanginkel/Projects/ChessBrowser/ChessBrowser/ChessToolsTests/kb2.pgn");
            Assert.AreEqual(games.Count, 1005);
        }
        [TestMethod]
        public void TestCorrectNumOfGamesKB3()
        {
            List<ChessGame> games = PGNReader.ReadFile("/Users/camillevanginkel/Projects/ChessBrowser/ChessBrowser/ChessToolsTests/kb3.pgn");
            Assert.AreEqual(games.Count, 1019);
        }
    }

    
}

